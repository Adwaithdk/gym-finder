/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Coffee, 
  MapPin, 
  Clock, 
  Phone, 
  Instagram, 
  Facebook, 
  MessageCircle, 
  ChevronRight, 
  Menu as MenuIcon, 
  X,
  Utensils,
  Cake,
  ArrowRight
} from 'lucide-react';

// --- Types ---
interface MenuItem {
  name: string;
  price: string;
  description: string;
}

interface MenuCategory {
  title: string;
  items: MenuItem[];
  icon: ReactNode;
}

// --- Constants ---
const MENU_DATA: MenuCategory[] = [
  {
    title: "Beverages",
    icon: <Coffee className="w-6 h-6" />,
    items: [
      { name: "Signature Hill Roast", price: "$4.50", description: "Slow-roasted beans from the high altitudes." },
      { name: "Station Latte", price: "$5.25", description: "Creamy espresso with a hint of vanilla and cinnamon." },
      { name: "Cold Brew Tonic", price: "$5.50", description: "Refreshing cold brew with premium tonic water." },
      { name: "Matcha Garden Latte", price: "$5.75", description: "Ceremonial grade matcha with oat milk." },
    ]
  },
  {
    title: "Snacks",
    icon: <Utensils className="w-6 h-6" />,
    items: [
      { name: "Avocado Sourdough", price: "$12.00", description: "Toasted sourdough with smashed avocado and chili flakes." },
      { name: "Truffle Fries", price: "$8.50", description: "Crispy fries tossed in truffle oil and parmesan." },
      { name: "Hillside Club Sandwich", price: "$14.00", description: "Triple-decker with smoked turkey and fresh greens." },
      { name: "Quiche of the Day", price: "$9.00", description: "Freshly baked savory pastry with seasonal fillings." },
    ]
  },
  {
    title: "Desserts",
    icon: <Cake className="w-6 h-6" />,
    items: [
      { name: "Classic Tiramisu", price: "$7.50", description: "Espresso-soaked ladyfingers with mascarpone cream." },
      { name: "Warm Apple Galette", price: "$8.00", description: "Rustic tart with caramelized apples and vanilla bean ice cream." },
      { name: "Dark Chocolate Lava Cake", price: "$9.00", description: "Molten center served with fresh berries." },
      { name: "Lemon Lavender Tart", price: "$7.00", description: "Zesty lemon curd with a hint of lavender." },
    ]
  }
];

const GALLERY_IMAGES = [
  "https://picsum.photos/seed/cafe1/800/600",
  "https://picsum.photos/seed/cafe2/800/600",
  "https://picsum.photos/seed/cafe3/800/600",
  "https://picsum.photos/seed/cafe4/800/600",
  "https://picsum.photos/seed/cafe5/800/600",
  "https://picsum.photos/seed/cafe6/800/600",
];

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'About', href: '#about' },
    { name: 'Menu', href: '#menu' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-cafe-cream/90 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a href="#" className="font-serif text-2xl font-bold tracking-tight text-cafe-brown">
          From Hill To Station
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium uppercase tracking-widest hover:text-cafe-olive transition-colors"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-cafe-brown" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X /> : <MenuIcon />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-cafe-cream border-t border-cafe-brown/10 p-6 md:hidden flex flex-col space-y-4 shadow-xl"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={() => setIsMenuOpen(false)}
                className="text-lg font-serif italic hover:text-cafe-olive transition-colors"
              >
                {link.name}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/seed/coffeemood/1920/1080?blur=2" 
          alt="Cafe Interior" 
          className="w-full h-full object-cover brightness-50"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="relative z-10 text-center px-6">
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-white/80 uppercase tracking-[0.3em] text-sm mb-4"
        >
          Established 2024
        </motion.p>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-8xl font-serif text-white mb-6 leading-tight"
        >
          From Hill To <br /> Station Café
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-xl md:text-2xl font-serif italic text-white/90 mb-10"
        >
          “From the Hills to Your Cup”
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <a 
            href="#menu" 
            className="inline-flex items-center px-8 py-4 bg-white text-cafe-brown rounded-full font-medium hover:bg-cafe-beige hover:text-white transition-all duration-300 group"
          >
            Explore Our Menu
            <ChevronRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50"
      >
        <div className="w-px h-12 bg-white/30 mx-auto mb-2" />
        <span className="text-[10px] uppercase tracking-widest">Scroll</span>
      </motion.div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
            <img 
              src="https://picsum.photos/seed/cafeabout/800/1000" 
              alt="Our Story" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-cafe-beige rounded-2xl -z-10 hidden md:block" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-cafe-olive font-medium uppercase tracking-widest text-sm mb-4 block">Our Story</span>
          <h2 className="text-4xl md:text-6xl font-serif mb-8 text-cafe-brown">A Journey of Flavor</h2>
          <p className="text-lg text-cafe-brown/70 mb-6 leading-relaxed">
            Nestled between the rolling hills and the bustling station, our café is more than just a stop—it's a destination. We believe in the poetry of a perfectly brewed cup and the comfort of a warm space.
          </p>
          <p className="text-lg text-cafe-brown/70 mb-8 leading-relaxed">
            Every bean is sourced with care, every snack prepared with passion. Whether you're seeking a quiet corner to write or a vibrant space to meet, we welcome you to experience the harmony of quality and freshness.
          </p>
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h4 className="font-serif text-2xl mb-2">Premium Beans</h4>
              <p className="text-sm text-cafe-brown/60">Sourced directly from high-altitude estates.</p>
            </div>
            <div>
              <h4 className="font-serif text-2xl mb-2">Fresh Daily</h4>
              <p className="text-sm text-cafe-brown/60">Our snacks and desserts are baked every morning.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const Menu = () => {
  return (
    <section id="menu" className="py-24 px-6 bg-cafe-cream">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-cafe-olive font-medium uppercase tracking-widest text-sm mb-4 block">Taste the Hills</span>
          <h2 className="text-4xl md:text-6xl font-serif text-cafe-brown">Our Curated Menu</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {MENU_DATA.map((category, idx) => (
            <motion.div 
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="glass-card rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-500"
            >
              <div className="w-12 h-12 bg-cafe-brown text-white rounded-full flex items-center justify-center mb-6">
                {category.icon}
              </div>
              <h3 className="text-3xl font-serif mb-8 border-b border-cafe-brown/10 pb-4">{category.title}</h3>
              <div className="space-y-8">
                {category.items.map((item) => (
                  <div key={item.name} className="group">
                    <div className="flex justify-between items-baseline mb-1">
                      <h4 className="font-medium text-lg group-hover:text-cafe-olive transition-colors">{item.name}</h4>
                      <span className="text-cafe-olive font-serif font-bold">{item.price}</span>
                    </div>
                    <p className="text-sm text-cafe-brown/60 italic">{item.description}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Gallery = () => {
  return (
    <section id="gallery" className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div>
            <span className="text-cafe-olive font-medium uppercase tracking-widest text-sm mb-4 block">Visual Journey</span>
            <h2 className="text-4xl md:text-6xl font-serif text-cafe-brown">Café Moments</h2>
          </div>
          <a href="#" className="flex items-center text-cafe-olive hover:underline underline-offset-8 transition-all">
            Follow us on Instagram <ArrowRight className="ml-2 w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
          {GALLERY_IMAGES.map((src, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              className="aspect-square rounded-2xl overflow-hidden hover-zoom cursor-pointer shadow-md"
            >
              <img 
                src={src} 
                alt={`Gallery ${idx}`} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Location = () => {
  return (
    <section id="contact" className="py-24 px-6 bg-cafe-brown text-white">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-6xl font-serif mb-12">Find Us</h2>
          
          <div className="space-y-10">
            <div className="flex gap-6">
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-xl font-serif mb-2">Address</h4>
                <p className="text-white/70">123 Hillside Avenue, Station Square,<br />Mountain View, CA 94043</p>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-xl font-serif mb-2">Opening Hours</h4>
                <div className="text-white/70 space-y-1">
                  <p className="flex justify-between w-48"><span>Mon - Fri:</span> <span>07:00 - 20:00</span></p>
                  <p className="flex justify-between w-48"><span>Sat - Sun:</span> <span>08:00 - 22:00</span></p>
                </div>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-xl font-serif mb-2">Contact</h4>
                <p className="text-white/70">+1 (555) 123-4567</p>
                <p className="text-white/70">hello@hilltostation.cafe</p>
              </div>
            </div>
          </div>

          <div className="mt-12 flex space-x-6">
            <a href="#" className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-cafe-brown transition-all">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="#" className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-cafe-brown transition-all">
              <Facebook className="w-5 h-5" />
            </a>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="rounded-3xl overflow-hidden h-[400px] md:h-full min-h-[400px] relative shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
        >
          {/* Placeholder for Google Maps - In a real app, use an iframe or Google Maps API */}
          <div className="absolute inset-0 bg-zinc-800 flex items-center justify-center text-center p-12">
            <div className="space-y-4">
              <MapPin className="w-12 h-12 mx-auto text-cafe-beige" />
              <p className="font-serif text-2xl">Interactive Map</p>
              <p className="text-white/50 text-sm">Click to open in Google Maps</p>
              <a 
                href="https://maps.google.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block px-6 py-3 bg-cafe-beige text-white rounded-full text-sm font-medium"
              >
                Get Directions
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 px-6 bg-cafe-cream border-t border-cafe-brown/5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <p className="font-serif text-xl font-bold text-cafe-brown">From Hill To Station</p>
        <p className="text-sm text-cafe-brown/50">© 2024 From Hill To Station Café. All rights reserved.</p>
        <div className="flex space-x-8 text-xs uppercase tracking-widest font-medium">
          <a href="#" className="hover:text-cafe-olive">Privacy Policy</a>
          <a href="#" className="hover:text-cafe-olive">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

const WhatsAppButton = () => {
  return (
    <motion.a
      href="https://wa.me/15551234567"
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className="fixed bottom-8 right-8 z-50 w-16 h-16 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-2xl hover:shadow-green-500/20 transition-all"
    >
      <MessageCircle className="w-8 h-8 fill-current" />
    </motion.a>
  );
};

export default function App() {
  return (
    <div className="relative">
      <Navbar />
      <Hero />
      <About />
      <Menu />
      <Gallery />
      <Location />
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
